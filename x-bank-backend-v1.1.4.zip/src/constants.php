<?php
	define('RESPONSE_EXSISTING_BENEFICIARY', 'Már van rögzítve ilyen néven kedvezményezett!');
	define('RESPONSE_EXSISTING_RECURRINGTRANSFER', 'Már van rögzítve ilyen néven állandó megbízás!');
	define('RESPONSE_INSUFFICIENT_BALANCE_2', 'Nincs elegendő pénz a számlán!');
	define('RESPONSE_INSUFFICIENT_BALANCE', 'Nincs elegendő pénz a számlán az utalás elvégzéséhez!');
	define('RESPONSE_MESSAGE_ID_LESS_THAN_NULL', 'Az ID nem lehet kisebb, mint nulla!');
	define('RESPONSE_MESSAGE_NO_DATA', 'Ilyen ID-vel nem található adat!');
	define('RESPONSE_MESSAGE_NOT_AUTHORIZED', 'Az oldal megtekintéséhez megfelelő jogosultság szükséges!');
	define('RESPONSE_UNSUCCESFUL_LOGIN', 'Hibás netbank azonosító vagy jelszó!');
	define('RESPONSE_UNSUCCESFUL_PASSWORD_CHANGE', 'Hibás a jelenlegi jelszó!');
  define('TOKEN_IS_EXPIRED', "Lejárt token!");
  define('TOKEN_LIFETIME', 3600);
