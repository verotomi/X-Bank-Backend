<?php

namespace Middlewares;

use Exception;
use Models\Token;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;

class AuthMiddleware
{
  public function __invoke(Request $request, RequestHandler $handler): Response
  {
    $auth = $request->getHeader('Authorization');
    if (count($auth) !== 1) {
      throw new Exception('Hibás Authorization header');
    }
    $authArr = mb_split(' ', $auth[0]);
    if ($authArr[0] !== 'Bearer') {
      throw new Exception("Nem támogatott autentikációs módszer");
    }
    $tokenStr = $authArr[1];
    $token = "";
    try {
      $token = Token::where('token', $tokenStr)->firstOrFail();
      $created = strtotime($token["created_at"]->format('Y-m-d H:i:s'));
      $updated = strtotime($token["updated_at"]->format('Y-m-d H:i:s'));
      $c = $created + 3600;
      $currenttime = time();
      $time = date('H:i', $created);
      $time2 = date('H:i', $updated);
      $time3 = date('H:i', $c);
      $time4 = date('H:i', $currenttime);
      $temp = $request->getParsedBody();
      if ($currenttime > $created + TOKEN_LIFETIME) {
        $response = new \Slim\Psr7\Response;
        $kimenet = json_encode(['error' => 'Lejárt token!']);
        $response->getBody()->write($kimenet);
        return $response;
      } else {
        return $handler->handle($request);
      }
    } catch (\Throwable $th) {
      $response = new \Slim\Psr7\Response;
      $response->getBody()->write('Nem létező token!');
      return $response;
    }
  }
}
